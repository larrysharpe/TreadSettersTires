Responsive Illustrator Template
-------------------------------

Two versions available, one with and one without the device overlays.

The overlays are very useful for when you are going to show clients what the designs will look like on different devices, but they include a lot of drop shadows (to look cool) slow down your document and add file size.

**Learn more**

  [lab post]: http://www.mimoymima.com/2012/06/lab/illustrator-responsive-design-template/
  [mimoYmima]: http://mimoymima.com